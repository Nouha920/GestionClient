import ma.projet.beans.Client;
import service.ClientService;

public class Test {
    public static void main(String[] args) {
        ClientService clientService = new ClientService();
        
        // Création de 5 clients
        Client c1 = new Client("Dupont", "Jean");
        
        Client c3 = new Client("Durand", "Pierre");
        Client c4 = new Client("Leroy", "Marie");
        Client c5 = new Client("Moreau", "Luc");
        
        
        clientService.create(c1);
        
        clientService.create(c3);
        clientService.create(c4);
        clientService.create(c5);
       
        
        // Afficher le client dont id = 3
        System.out.println("Client avec id=3 : " + clientService.findById(3));
        
        // Supprimer le client dont id = 3
      // Supprimer le client dont le nom est "Martin"
    for (Client client : clientService.findAll()) {
         if (client.getNom().equalsIgnoreCase("tasnim")) {
           clientService.delete(client);
           System.out.println("Client avec nom='Martin' supprimé");
        break; // Si tu veux supprimer juste le premier trouvé
    }
}

        
        // Modifier le client dont id = 2
        Client toUpdate = clientService.findById(2);
        if (toUpdate != null) {
            toUpdate.setNom("Martin modifié");
            toUpdate.setPrenom("Sophie modifiée");
            clientService.update(toUpdate);
            System.out.println("Client avec id=2 modifié");
        }
        
        // Afficher la liste des clients
        System.out.println("\nListe des clients:");
        for (Client client : clientService.findAll()) {
            System.out.println(client);
        }
    }
}